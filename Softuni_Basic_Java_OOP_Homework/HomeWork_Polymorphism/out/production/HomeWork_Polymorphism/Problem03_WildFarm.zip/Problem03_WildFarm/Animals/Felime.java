package Problem03_WildFarm.Animals;

public class Felime extends Mammal {

    public Felime(String animalName, String animalType, double animalWeight, String livingRegion) {
        super(animalName, animalType, animalWeight, livingRegion);
    }
}
