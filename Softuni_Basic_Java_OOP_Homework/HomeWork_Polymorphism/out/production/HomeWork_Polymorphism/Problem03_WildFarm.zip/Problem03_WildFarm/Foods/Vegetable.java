package Problem03_WildFarm.Foods;

public class Vegetable extends Food {

    public Vegetable(int quantities) {
        super(quantities);
    }
}
