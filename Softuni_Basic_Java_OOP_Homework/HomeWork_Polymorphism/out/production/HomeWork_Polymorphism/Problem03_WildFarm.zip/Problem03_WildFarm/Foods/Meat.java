package Problem03_WildFarm.Foods;

public class Meat extends Food {

    public Meat(int quantities) {
        super(quantities);
    }
}
