package Problem06_Animal.Interfaces;

public interface SoundProducible {
    String produceSound();
}
