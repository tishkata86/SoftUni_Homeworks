package Problem08_MilitaryElite.Interfaces;

public interface PartInterface {

    String getName();

    int getHours();
}
