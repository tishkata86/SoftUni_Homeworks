package Problem08_MilitaryElite.Interfaces;

public interface PrivateInterface extends SoldierInterface{

    double getSalary();
}
