package Problem08_MilitaryElite.Interfaces;

public interface SpecialSoldierInterface extends PrivateInterface {

    String getCorps();
}
