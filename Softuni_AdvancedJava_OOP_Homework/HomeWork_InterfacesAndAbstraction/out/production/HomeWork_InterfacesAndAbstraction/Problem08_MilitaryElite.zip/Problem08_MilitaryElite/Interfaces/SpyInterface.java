package Problem08_MilitaryElite.Interfaces;

public interface SpyInterface extends SoldierInterface{

    String getCodeNumber();
}
