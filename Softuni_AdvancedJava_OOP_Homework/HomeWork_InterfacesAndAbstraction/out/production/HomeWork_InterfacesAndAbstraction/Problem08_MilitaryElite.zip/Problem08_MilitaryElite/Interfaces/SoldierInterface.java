package Problem08_MilitaryElite.Interfaces;

public interface SoldierInterface {

    String getId();

    String getFirstName();

    String getLastName();
}
