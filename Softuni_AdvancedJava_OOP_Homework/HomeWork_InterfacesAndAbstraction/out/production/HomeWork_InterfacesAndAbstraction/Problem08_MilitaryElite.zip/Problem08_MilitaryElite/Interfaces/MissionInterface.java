package Problem08_MilitaryElite.Interfaces;

public interface MissionInterface {

    String getCodeName();

    String getState();
}
